#!/bin/bash
export LANG=C

data=$( date +%A )

if [ $data = "Saturday" -o $data = "Sunday" ] 
then
 echo "WEEKEND"
else
 echo "Tydzien";
fi
        
